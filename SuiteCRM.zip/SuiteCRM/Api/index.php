<?php
chdir('../');
require_once __DIR__ . '/Core/app.php';
$app->run();
