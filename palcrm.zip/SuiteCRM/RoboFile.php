<?php
/**
 * This is the project's configuration for Robo task runner. This doesn't actually do anything
 * other than exist, to prevent invalid Robo commands from returning unrelated errors.
 *
 * @see http://robo.li/
 */
class RoboFile extends \Robo\Tasks
{
    // This space intentionally left blank.
}
