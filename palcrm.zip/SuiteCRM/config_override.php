<?php
/***CONFIGURATOR***/
$sugar_config['disable_persistent_connections'] = false;
/***CONFIGURATOR***/