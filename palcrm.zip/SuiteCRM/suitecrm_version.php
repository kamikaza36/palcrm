<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.12';
$suitecrm_timestamp = '2020-02-14 17:00:00';
